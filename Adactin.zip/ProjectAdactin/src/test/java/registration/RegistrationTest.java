package registration;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegistrationRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class RegistrationTest 
{
  WebDriver driver;
  @BeforeTest
  public void beforeTest()
  {
	  WebDriverManager.chromedriver().setup();
	  driver= new ChromeDriver();
	  driver.manage().window().maximize();

	  
  }
  @Test
  public void adactinregistration() throws Exception
  {
	    FileInputStream file=new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\ProjectAdactin\\data\\Adactin.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("Registration");
		
		int rowSize=s.getLastRowNum();
		System.out.println("No of keyword: "+rowSize);
		
		RegistrationRepo r=new RegistrationRepo();
		
		for(int i=1; i<=rowSize; i++)
		{
			
			String username=(String) s.getRow(i).getCell(0).getStringCellValue();
			String password=(String) s.getRow(i).getCell(1).getStringCellValue();
			String cpwd=(String) s.getRow(i).getCell(2).getStringCellValue();
			String name=(String) s.getRow(i).getCell(3).getStringCellValue();
			String email=(String) s.getRow(i).getCell(4).getStringCellValue();
			
			System.out.println(username+"\t\t"+password+"\t\t"+cpwd+"\t\t"+name+"\t\t"+email);
			
			try
			{
				RegistrationRepo.url(driver);
				Thread.sleep(4000);
//				RegistrationRepo.clickonRegister(driver);
//				Thread.sleep(2000);
				RegistrationRepo.Enterusername(driver).sendKeys(username);
				Thread.sleep(2000);
				RegistrationRepo.Enterpassword(driver).sendKeys(password);
				Thread.sleep(2000);
				RegistrationRepo.Enterconfirmpassword(driver).sendKeys(cpwd);
				Thread.sleep(2000);
				RegistrationRepo.Fullname(driver).sendKeys(name);
				Thread.sleep(2000);
				RegistrationRepo.Emailaddress(driver).sendKeys(email);
				Thread.sleep(15000);
				RegistrationRepo.Checkbox(driver);
				Thread.sleep(2000);
				RegistrationRepo.Register(driver);
				
				System.out.println("Valid data");
			}
			catch (Exception e)
			{
				System.out.println(driver.getTitle());
			}
	  
		}
  }

  @AfterTest
  public void afterTest() throws Exception
  {
//	  Thread.sleep(20000);
//	  RegistrationRepo.closeBrowser(driver);	  
  }

}
