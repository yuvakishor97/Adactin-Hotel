package bookAHotel;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SearchRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class BookaHotel 
{
  WebDriver driver;
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  driver= new ChromeDriver();
	  driver.manage().window().maximize();
	  
  }
  @Test
  public void bookahotel() throws Exception 
  {
	  FileInputStream file=new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\ProjectAdactin\\data\\Adactin.xlsx");
	  XSSFWorkbook w=new XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("BookAHotel");
		
	  int rowSize=s.getLastRowNum();
	  System.out.println("No of keyword: "+rowSize);
	  
	  SearchRepo S=new SearchRepo();
	  
	  SearchRepo.url(driver);
		Thread.sleep(2000);
		SearchRepo.username(driver).sendKeys("yuvakishor97");
		Thread.sleep(2000);
		SearchRepo.password(driver).sendKeys("9951848097");
		Thread.sleep(2000);
		SearchRepo.Login(driver);
		Thread.sleep(2000);
		SearchRepo.Location(driver).sendKeys("Sydney");
		Thread.sleep(2000);
		SearchRepo.Hotels(driver).sendKeys("Hotel Creek");
		Thread.sleep(2000);
		SearchRepo.Roomtype(driver).sendKeys("Double");
		Thread.sleep(2000);
		SearchRepo.numberofrooms(driver).sendKeys("2 - Two");
		Thread.sleep(2000);
		SearchRepo.DateINclear(driver);
		Thread.sleep(2000);
		SearchRepo.DateOutclear(driver);
		Thread.sleep(2000);
		SearchRepo.checkinDate(driver).sendKeys("28-10-2022");
		Thread.sleep(2000);
		SearchRepo.checkoutDate(driver).sendKeys("29-10-2022");
		Thread.sleep(2000);
		SearchRepo.adultsperRoom(driver).sendKeys("2 - Two");
		Thread.sleep(2000);
		SearchRepo.childrenperRoom(driver).sendKeys("2 - Two");
		SearchRepo.search(driver);
		Thread.sleep(2000);
		SearchRepo.selectHotel(driver);
		Thread.sleep(2000);
		SearchRepo.continueButton(driver);
		Thread.sleep(2000);
	  
	  for(int i=1; i<=rowSize; i++)
		{
			String Firstname  =(String) s.getRow(i).getCell(0).getStringCellValue();
			String Lastname=(String) s.getRow(i).getCell(1).getStringCellValue();
			String BillingAddress=(String) s.getRow(i).getCell(2).getStringCellValue();
			String CreditCardNo=(String) s.getRow(i).getCell(3).getStringCellValue();
			String CreditCardType=(String) s.getRow(i).getCell(4).getStringCellValue();
			String ExpiryMonth=(String) s.getRow(i).getCell(5).getStringCellValue();
			String ExpiryYear=(String) s.getRow(i).getCell(6).getStringCellValue();
			String Cvvno=(String) s.getRow(i).getCell(7).getStringCellValue();
			System.out.println(Firstname+"\t\t"+Lastname+"\t\t"+BillingAddress+"\t\t"+CreditCardNo+"\t\t"+CreditCardType+"\t\t"+ ExpiryMonth+"\t\t"+ExpiryYear+"\t\t"+Cvvno);
			
			try
			{
			
			SearchRepo.bookaHotelFirstName(driver).sendKeys(Firstname);
			Thread.sleep(2000);
			SearchRepo.bookaHotelLastName(driver).sendKeys(Lastname);
			Thread.sleep(2000);
			SearchRepo.bookaHotelBillingaddress(driver).sendKeys(BillingAddress);
			Thread.sleep(2000);
			SearchRepo.bookaHotelCreditcardNo(driver).sendKeys(CreditCardNo);
			Thread.sleep(2000);
			SearchRepo.bookaHotelCreditcardType(driver).sendKeys(CreditCardType);
			Thread.sleep(2000);
			SearchRepo.bookaHotelcardExpiryMonth(driver).sendKeys(ExpiryMonth);
			Thread.sleep(2000);
			SearchRepo.bookaHotelcardExpiryyear(driver).sendKeys(ExpiryYear);
			Thread.sleep(2000);
			SearchRepo.bookaHotelcardcvvNo(driver).sendKeys(Cvvno);
			Thread.sleep(2000);
			SearchRepo.bookaHotelBookNow(driver);
			
			System.out.println(driver.getTitle());
            }
			catch(Exception e)
			{
				System.out.println(driver.getTitle());
			}
		}
 
  }
  @AfterTest
  public void afterTest()
  {
	  SearchRepo.closeBrowser(driver);
  }

}
