package searchHotel;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SearchRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SearchTest 
{
	WebDriver driver;
  @BeforeTest
  public void beforeTest() 
  {
   WebDriverManager.chromedriver().setup();
   driver= new ChromeDriver();
   driver.manage().window().maximize();
		  
  }
  @Test
  public void searchHotel() throws Exception
  {
	  FileInputStream file=new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\ProjectAdactin\\data\\Adactin.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("SearchHotel");
		
		int rowSize=s.getLastRowNum();
		System.out.println("No of keyword: "+rowSize);
		
		SearchRepo 	S=new SearchRepo();
		
		SearchRepo.url(driver);
		Thread.sleep(2000);
		SearchRepo.username(driver).sendKeys("yuvakishor97");
		Thread.sleep(2000);
		SearchRepo.password(driver).sendKeys("9951848097");
		Thread.sleep(2000);
		SearchRepo.Login(driver);
		Thread.sleep(2000);
		
		for(int i=1; i<=rowSize; i++)
		{
			String Location =(String) s.getRow(i).getCell(0).getStringCellValue();
			String Hotels=(String) s.getRow(i).getCell(1).getStringCellValue();
			String RoomType=(String) s.getRow(i).getCell(2).getStringCellValue();
			String NumberofRooms=(String) s.getRow(i).getCell(3).getStringCellValue();
			String CheckInDate=(String) s.getRow(i).getCell(4).getStringCellValue();
			String CheckOutDate=(String) s.getRow(i).getCell(5).getStringCellValue();
			String AdultsperRoom=(String) s.getRow(i).getCell(6).getStringCellValue();
			String ChildrenperRoom=(String) s.getRow(i).getCell(7).getStringCellValue();
			
			System.out.println(Location+"\t\t"+Hotels+"\t\t"+RoomType+"\t\t"+NumberofRooms+"\t\t"+CheckInDate+"\t\t"+CheckOutDate+"\t\t"+AdultsperRoom+"\t\t"+ChildrenperRoom);
			
			try
			{
			
			SearchRepo.Location(driver).sendKeys(Location);
			Thread.sleep(2000);
			SearchRepo.Hotels(driver).sendKeys(Hotels);
			Thread.sleep(2000);
			SearchRepo.Roomtype(driver).sendKeys(RoomType);
			Thread.sleep(2000);
			SearchRepo.numberofrooms(driver).sendKeys(NumberofRooms);
			Thread.sleep(2000);
			SearchRepo.DateINclear(driver);
			Thread.sleep(2000);
			SearchRepo.DateOutclear(driver);
			Thread.sleep(2000);
			SearchRepo.checkinDate(driver).sendKeys(CheckInDate);
			Thread.sleep(2000);
			SearchRepo.checkoutDate(driver).sendKeys(CheckOutDate);
			Thread.sleep(2000);
			SearchRepo.adultsperRoom(driver).sendKeys(AdultsperRoom);
			Thread.sleep(2000);
			SearchRepo.childrenperRoom(driver).sendKeys(ChildrenperRoom);
			SearchRepo.search(driver);
			System.out.println(driver.getTitle());
		}
			catch (Exception e)
			{
				System.out.println(driver.getTitle());
			}
		}
	  
  }
  @AfterTest
  public void afterTest()
  {
	  SearchRepo.closeBrowser(driver);
  }

}
