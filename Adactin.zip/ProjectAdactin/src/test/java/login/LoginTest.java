package login;

import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.LoginRepo;
import org.testng.annotations.BeforeTest;
import java.io.FileInputStream;



import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class LoginTest 
{
	WebDriver driver;
 
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  driver= new ChromeDriver();
	  driver.manage().window().maximize();
	   
  }
  @Test
  public void adactinlogin() throws Exception 
  {
	  FileInputStream file=new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\ProjectAdactin\\data\\Adactin.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("Login");
		
		int rowSize=s.getLastRowNum();
		System.out.println("No of keyword: "+rowSize);
		
		LoginRepo l=new LoginRepo();
		
		for(int i=1; i<=rowSize; i++)
		{
			
			String usn=(String) s.getRow(i).getCell(0).getStringCellValue();
			String pwd=(String) s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(usn+"\t\t"+pwd);
			
			try
			{
				LoginRepo.url(driver);
				Thread.sleep(2000);
				LoginRepo.username(driver).sendKeys(usn);
				Thread.sleep(2000);
				LoginRepo.password(driver).sendKeys(pwd);
				Thread.sleep(2000);
				LoginRepo.Login(driver);
				Thread.sleep(2000);
				LoginRepo.Logout(driver);
				Thread.sleep(2000);
				
				System.out.println("Valid username and password");
				
			}
			catch (Exception e)
			{
				System.out.println("Invalid username and password");
				
			}
		}
		  
  }

  @AfterTest
  public void afterTest()  
  {
	        LoginRepo.closebrowser(driver);
	  
  }

}
