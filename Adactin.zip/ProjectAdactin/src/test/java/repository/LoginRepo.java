package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginRepo 
{   
	static WebElement element;
	public static void url(WebDriver driver)
	{
		driver.get("http://adactinhotelapp.com/index.php");
	}
	public  static WebElement username(WebDriver driver)
	{
		element=driver.findElement(By.name("username"));
		return element;
	}
	public static WebElement password(WebDriver driver)
	{
		element=driver.findElement(By.name("password"));
		return element;
	}
	public static void Login(WebDriver driver)
	{
		driver.findElement(By.name("login")).click();
	}
	public static void Logout(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/table[2]/tbody/tr[1]/td[2]/a[4]")).click();
	}
	public static void closebrowser(WebDriver driver)
	{
		driver.close();
	}
}
