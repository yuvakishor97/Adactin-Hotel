package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchRepo 
{
	static WebElement element;
	public static void url(WebDriver driver)
	{
		driver.get("http://adactinhotelapp.com/index.php");
	}
	public  static WebElement username(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"username\"]"));
		return element;
		
	}
	public static WebElement password(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"password\"]"));
		return element;
	}
	public static void Login(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
	}
	public static WebElement Location(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"location\"]"));
		return element;
	}
	public static WebElement Hotels(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"hotels\"]"));
		return element;
	}
	public static WebElement Roomtype(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"room_type\"]"));
		return element;
	}
	public static WebElement numberofrooms(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"room_nos\"]"));
		return element;
	}
	public static void DateINclear(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"datepick_in\"]")).clear();
	}
	public static WebElement checkinDate(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"datepick_in\"]"));
		return element;
	}
	public static void DateOutclear(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"datepick_out\"]")).clear();
	}
	public static WebElement checkoutDate(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"datepick_out\"]"));
		return element;
	}
	public static WebElement adultsperRoom(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"adult_room\"]"));
		return element;
	}
	public static WebElement childrenperRoom(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"child_room\"]"));
		return element;
	}
	public static void search(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"Submit\"]")).click();
	}
	public static void selectHotel(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"radiobutton_0\"]")).click();
	}
	public static void continueButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
	}
	public static WebElement bookaHotelFirstName(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"first_name\"]"));
		return element;
	}
	public static WebElement bookaHotelLastName(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"last_name\"]"));
		return element;
	}
	public static WebElement bookaHotelBillingaddress(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"address\"]"));
		return element;
	}
	public static WebElement bookaHotelCreditcardNo(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cc_num\"]"));
		return element;
	}
	public static WebElement bookaHotelCreditcardType(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cc_type\"]"));
		return element;
	}
	public static WebElement bookaHotelcardExpiryMonth(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cc_exp_month\"]"));
		return element;
	}
	public static WebElement bookaHotelcardExpiryyear(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cc_exp_year\"]"));
		return element;
	}
	public static WebElement bookaHotelcardcvvNo(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"cc_cvv\"]"));
		return element;
	}
	public static void bookaHotelBookNow(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"book_now\"]")).click();
	}
	public static void logout(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/table[2]/tbody/tr[1]/td[2]/a[4]")).click();
	}
	public static void closeBrowser(WebDriver driver)
	{
		driver.close();
	}
	
	

}
