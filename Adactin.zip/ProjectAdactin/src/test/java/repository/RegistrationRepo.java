package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationRepo
{
	static WebElement element;
	public static void url(WebDriver driver)
	{
		driver.get("https://adactinhotelapp.com/Register.php");
	}
//	public static WebElement clickonRegister(WebDriver driver)
//	{
//		element=driver.findElement(By.xpath("//*[@id=\"login_form\"]/table/tbody/tr[7]/td/a"));
//		return element;
//	}
	public static WebElement Enterusername(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"username\"]"));
		return element;
	}
	public static WebElement Enterpassword(WebDriver driver)
	{
		element=driver.findElement(By.name("password"));
		return element;
	}
	public static WebElement Enterconfirmpassword(WebDriver driver)
	{
		element=driver.findElement(By.name("re_password"));
		return element;
		
	}
	public static WebElement Fullname(WebDriver driver)
	{
		element=driver.findElement(By.name("full_name"));
		return element;
	}
	public static WebElement Emailaddress(WebDriver driver)
	{
		element=driver.findElement(By.name("email_add"));
		return element;
	}
	public static void Checkbox(WebDriver driver)
	{
		driver.findElement(By.name("tnc_box")).click();;
	}
	public static void Register(WebDriver driver)
	{
		driver.findElement(By.name("Submit")).click();
		
	}
	public static void closeBrowser(WebDriver driver)
	{
		driver.close();
	}
	
	
	

}
