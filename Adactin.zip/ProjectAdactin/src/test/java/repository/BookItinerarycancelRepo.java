package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BookItinerarycancelRepo 
{
	static WebElement element;
	public static void url(WebDriver driver)
	{
		driver.get("http://adactinhotelapp.com/index.php");
	}
	public  static WebElement username(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"username\"]"));
		return element;	
	}
	public static WebElement password(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"password\"]"));
		return element;
	}
	public static void Login(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
	}
	public static void bookedItineray(WebDriver driver)
	{
		driver.findElement(By.xpath("/html/body/table[2]/tbody/tr[1]/td[2]/a[2]")).click();
	}
	public static void bookedItinerayselectOrderID(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"check_all\"]")).click();
	}
	public static void bookedItineraycanceledSelected(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"booked_form\"]/table/tbody/tr[3]/td/input[1]")).click();
	}
	public static void closeBrowser(WebDriver driver)
	{
		driver.close();
	}
	

}
