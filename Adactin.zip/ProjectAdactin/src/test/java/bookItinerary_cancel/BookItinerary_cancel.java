package bookItinerary_cancel;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.BookItinerarycancelRepo;
import repository.SearchRepo;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class BookItinerary_cancel 
{
  WebDriver driver;	
  @BeforeTest	
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();	  
  }
  @Test
  public void BookItinerarycancel() throws Exception 
  {
	  BookItinerarycancelRepo b=new BookItinerarycancelRepo();
	  
	  BookItinerarycancelRepo.url(driver);
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.username(driver).sendKeys("yuvakishor97");;
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.password(driver).sendKeys("9951848097");;
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.Login(driver);
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.bookedItineray(driver);
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.bookedItinerayselectOrderID(driver);
	  Thread.sleep(2000);
	  BookItinerarycancelRepo.bookedItineraycanceledSelected(driver);
	  Thread.sleep(2000);
	  driver.switchTo().alert().getText();
	  Thread.sleep(2000);
	  driver.switchTo().alert().accept();
	  Thread.sleep(2000);
	  SearchRepo.logout(driver);
	  
  }

  @AfterTest
  public void afterTest() 
  {
	  BookItinerarycancelRepo.closeBrowser(driver);
	  
  }

}
