package changepassword;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.ChangepasswordRepo;
import repository.SearchRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ChangepasswordTest 
{ WebDriver driver;
  @BeforeTest
  public void beforeTest() 
  {
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();  
  }
  @Test
  public void changepassword() throws Exception 
  {
	  FileInputStream file=new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\ProjectAdactin\\data\\Adactin.xlsx");
	  XSSFWorkbook w=new XSSFWorkbook(file);
	  XSSFSheet s=w.getSheet("ChangePassword");
	  
	  int rowSize=s.getLastRowNum();
	  System.out.println("No of Keyword: "+ rowSize);
	  
	  ChangepasswordRepo c=new  ChangepasswordRepo();
	  
	  ChangepasswordRepo.url(driver);
	  Thread.sleep(2000);
	  ChangepasswordRepo.username(driver).sendKeys("yuvakishor97");
	  Thread.sleep(2000);
	  ChangepasswordRepo.password(driver).sendKeys("9951848097");
	  Thread.sleep(2000);
	  ChangepasswordRepo.Login(driver);
	  Thread.sleep(2000);
	  ChangepasswordRepo.Changepassword(driver);
	  Thread.sleep(2000);
	  
	  for(int i=1; i<=rowSize; i++)
	  {
		  String CurrentPassword=(String) s.getRow(i).getCell(0).getStringCellValue();
		  String NewPassword    =(String) s.getRow(i).getCell(1).getStringCellValue();
		  String ConfirmPassword=(String) s.getRow(i).getCell(2).getStringCellValue();
		  
		  System.out.println(CurrentPassword+"\t\t"+NewPassword+"\t\t"+ConfirmPassword);
	  
	  try
	  {
	  
	  ChangepasswordRepo.ChangepasswordCurrentpassword(driver).sendKeys(CurrentPassword);
	  Thread.sleep(2000);
	  ChangepasswordRepo.ChangepasswordNewpassword(driver).sendKeys(NewPassword);
	  Thread.sleep(2000);
	  ChangepasswordRepo.ChangepasswordConfirmpassword(driver).sendKeys(ConfirmPassword);
	  Thread.sleep(2000);
	  ChangepasswordRepo.ChangepasswordSubmit(driver);

	  
	  System.out.println("valid data");
      }
	  catch (Exception e)
	  {
		  System.out.println("invalid data");
	  }
	}
}
@AfterTest
  public void afterTest() 
  {
	ChangepasswordRepo.closeBrowser(driver);
	  
  }

}
